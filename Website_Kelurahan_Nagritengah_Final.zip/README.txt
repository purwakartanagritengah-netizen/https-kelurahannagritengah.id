WEBSITE KELURAHAN NAGRITENGAH
================================

Isi:
- index.html : website utama (langsung dapat dibuka di browser)

Cara membuka:
1. Ekstrak file ZIP.
2. Klik dua kali index.html.
3. Untuk dipublikasikan, unggah index.html ke hosting/domain.

Data awal yang dimasukkan:
- Penduduk 2024: 11.472 jiwa
- Laki-laki: 5.755 jiwa
- Perempuan: 5.717 jiwa
- Kepadatan: 5.975 jiwa/km²
- Luas wilayah: 1,92 km² (dataset 2019)
- Alamat kantor: JL. Hidayat Martalogawa No. 16, Kelurahan Nagritengah, Kecamatan Purwakarta, Kabupaten Purwakarta
- Telepon: (0264) 214445

Catatan:
- Silakan verifikasi data kontak dan jam layanan sebelum menjadikannya website resmi.
- Peta menggunakan Google Maps embed, sehingga membutuhkan koneksi internet.
- Batas wilayah RW/RT presisi dapat ditambahkan jika tersedia file GeoJSON/KML.
